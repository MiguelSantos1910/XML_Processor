import * as resumoService from "../services/resumoService.js";

export async function listarResumo(req, res) {
    try{
        const resumo = await resumoService.buscarResumo();
        return res.status(200).json(resumo);
    }catch(error){
        return res.status(500).json({mensagem: "Erro ao gerar o resumo", erro: error.message});
    }
}