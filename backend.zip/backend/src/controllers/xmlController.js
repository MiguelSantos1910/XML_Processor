import * as xmlService from "../repositories/notaFiscalRepository.js";

export async function listarNotas(req, res) {

    try {
        const notas = await xmlService.listarNotas();
        return res.status(200).json(notas);
    } catch (error) {
        return res.status(500).json({
            mensagem: "Erro ao listar notas.",
            erro: error.message
        });
    }
}

export async function listarNaoIdentificados(req, res) {

    try {
        const notas = await xmlService.listarNaoIdentificados();
        return res.status(200).json(notas);
    } catch (error) {
        return res.status(500).json({
            mensagem: "Erro ao listar XMLs não identificados.",
            erro: error.message
        });
    }
}