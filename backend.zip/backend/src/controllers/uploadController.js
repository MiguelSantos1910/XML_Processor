import * as uploadService from "../services/uploadService.js";

export async function uploadArquivos(req, res) {
    try{
        if(!req.files || req.files.length === 0){
            return res.status(400).json({message: "Nenhum arquivo enviado."});
        }
        await uploadService.enviarParaFila(req.files);
        return res.status(202).json({mensagem: "Arquivos enviados para processamento.", quantidade: req.files.length});
    }catch(error){
        return res.status(500).json({mensagem: "Erro ao realizar upload.", erro: error.message});
    }
}