import { processarXML } from "../consumers/xmlConsumer.js";
import logger from "./logger.js";

const fila = [];
let processando = false;

export function adicionarNaFila(caminhoArquivo) {
    fila.push(caminhoArquivo);
    logger.info({ arquivo: caminhoArquivo }, "Arquivo adicionado à fila");

    if (!processando) {
        iniciarFila();
    }
}

async function iniciarFila() {
    processando = true;
    while (fila.length > 0) {
        const caminhoArquivo = fila.shift();
        try {
            await processarXML(caminhoArquivo);
            logger.info({ arquivo: caminhoArquivo }, "XML processado com sucesso");
        } catch (error) {
            logger.error({ arquivo: caminhoArquivo, erro: error.message }, "Erro ao processar XML");
        }
    }
    processando = false;
}