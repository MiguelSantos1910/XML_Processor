import mongoose from "mongoose";
import logger from "./logger.js";

export async function conectarBanco() {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        logger.info("MongoDB conectado com sucesso");
    } catch (error) {
        logger.fatal({ erro: error.message }, "Erro ao conectar no MongoDB");
        process.exit(1);
    }
}