import multer from "multer";
import path from "path";

const storage = multer.diskStorage({
    destination: "uploads/",
    filename: (req, file, cb) =>{
        cb(null, `${Date.now}-${file.originalname}`);
    }
});

const fileFilter = (req, file, cb) =>{
    const extensao = path.extname(file.originalname).toLocaleLowerCase();
    if(extensao !== ".xml"){
        return cb(new Error("Apenas arquivos XML são aceitos."));
    }
    cb(null, true);
};

export default multer({
    storage,
    fileFilter,
    limits: {
        fileSize: 5 * 1024 * 1024 //Suporta até 5MB
    }
});