export async function tratamentoErros(err, req, res, next) {
    return res.status(400).json({erro: error.message});
}