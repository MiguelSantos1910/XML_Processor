import fs from "fs";
import { XMLParser } from "fast-xml-parser";

export async function lerXML(caminhoArquivo) {
    const xml = fs.readFileSync(caminhoArquivo, "utf8");

    const parser = new XMLParser({
        ignoreAttributes: false,
        removeNSPrefix: true,
        parseTagValue: false
    });

    const json = parser.parse(xml);

    const nfeProc = json.nfeProc;
    const nota = nfeProc?.NFe?.infNFe ?? json.NFe?.infNFe;

    if (!nota) {
        throw new Error("Estrutura do XML não reconhecida: tag infNFe não encontrada.");
    }

    return {
        chaveNota: nota["@_Id"]?.replace("NFe", ""),
        emitente: nota.emit?.xNome,
        destinatario: nota.dest?.xNome,
        cnpjEmitente: String(nota.emit?.CNPJ),
        cnpjDestinatario: String(nota.dest?.CNPJ),
        valorTotal: Number(nota.total?.ICMSTot?.vNF),
        dataEmissao: nota.ide?.dhEmi || nota.ide?.dEmi
    };
}