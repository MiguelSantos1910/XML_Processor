import { processarXML } from "../consumers/xmlConsumer.js";
const fila = [];

export async function adicionarNaFila(caminho) {
    fila.push(caminho);
}

export async function iniciarConsumer() {
    while(true){
        if(fila.length > 0){
            const caminho = fila.shift();
            await processarXML(caminho);
        }
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}