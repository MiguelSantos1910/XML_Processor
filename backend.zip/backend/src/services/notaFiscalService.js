import Nota from "../models/Nota.js";

export async function processarNota(nota, clientes) {
    let tipo = "Não identificado";
    let cliente = null;

    const emitenteInterno = clientes.find(c => c.cnpj === nota.cnpjEmitente);
    const destinatarioInterno = clientes.find(c => c.cnpj === nota.cnpjDestinatario);

    if (destinatarioInterno) {
        tipo = "Compra";
        cliente = destinatarioInterno.nome || nota.destinatario;
    } else if (emitenteInterno) {
        tipo = "Venda";
        cliente = emitenteInterno.nome || nota.emitente;
    }

    await Nota.create({
        ...nota,
        tipoOperacao: tipo,
        cliente
    });
}