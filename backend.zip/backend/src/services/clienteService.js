import axios from "axios";
import logger from "../config/logger.js";

export async function buscarClientes() {
    try {
        const api = axios.create({ baseURL: process.env.CLIENTES_API });
        const response = await api.get("/clientes");
        return response.data;
    } catch (error) {
        logger.error({ erro: error.message }, "Erro ao consultar API de clientes");
        throw new Error(`Erro ao consultar API de clientes: ${error.message}`);
    }
}