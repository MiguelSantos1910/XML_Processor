import { adicionarNaFila } from "../config/queue.js";

export async function enviarParaFila(arquivos){
    
    arquivos.forEach((arquivo)=>{
        adicionarNaFila(arquivo.path);
    });
}