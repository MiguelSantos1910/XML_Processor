import Nota from "../models/Nota.js";

export async function buscarResumo() {
    return await Nota.aggregate([
        {
            $match: { tipoOperacao: { $ne: "Não identificado" } }
        },
        {
            $group: {
                _id: "$cliente",
                compraValor: {
                    $sum: { $cond: [{ $eq: ["$tipoOperacao", "Compra"] }, "$valorTotal", 0] }
                },
                compraQtd: {
                    $sum: { $cond: [{ $eq: ["$tipoOperacao", "Compra"] }, 1, 0] }
                },
                vendaValor: {
                    $sum: { $cond: [{ $eq: ["$tipoOperacao", "Venda"] }, "$valorTotal", 0] }
                },
                vendaQtd: {
                    $sum: { $cond: [{ $eq: ["$tipoOperacao", "Venda"] }, 1, 0] }
                }
            }
        },
        {
            $project: {
                _id: 0,
                cliente: "$_id",
                compraValor: 1,
                compraQtd: 1,
                vendaValor: 1,
                vendaQtd: 1
            }
        }
    ]);
}