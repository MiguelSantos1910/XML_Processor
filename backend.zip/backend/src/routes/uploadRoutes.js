import express from "express";
import multer from "multer";
import * as uploadController from "../controllers/uploadController.js";

const router = express.Router();

const upload = multer({
    dest: "upload/"
});

/**
 * @swagger
 * /api/upload:
 *   post:
 *     summary: Realiza upload de arquivos XML de NF-e
 *     description: Recebe um ou vários arquivos XML, processa e armazena os dados das notas fiscais.
 *     tags:
 *       - Upload
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               xml:
 *                 type: array
 *                 items:
 *                   type: string
 *                   format: binary
 *                 description: Arquivos XML da NF-e
 *     responses:
 *       200:
 *         description: Arquivos enviados e processados com sucesso
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 mensagem:
 *                   type: string
 *                   example: Arquivos processados com sucesso
 *                 arquivos:
 *                   type: array
 *                   items:
 *                     type: string
 *                     example: nota123.xml
 *       400:
 *         description: Nenhum arquivo enviado ou XML inválido
 *       500:
 *         description: Erro interno no processamento
 */
router.post(
    "/upload",
    upload.array("xml"),
    uploadController.uploadArquivos
);

export default router;