import express from "express";

const app = express();

app.get("/clientes", (req, res) => {
    res.json([
        {
            id: 1,
            nome: "Empresa ABC",
            cnpj: "12345678000199"
        },
        {
            id: 2,
            nome: "Empresa XPTO",
            cnpj: "98765432000188"
        }
    ]);
});

app.listen(3000);