import express from "express";
import * as xmlController from "../controllers/xmlController.js";

const router = express.Router();

/**
 * @swagger
 * /api/notas:
 *   get:
 *     summary: Lista todas as notas fiscais processadas
 *     description: Retorna as notas fiscais XML armazenadas no banco de dados.
 *     tags:
 *       - Notas Fiscais
 *     responses:
 *       200:
 *         description: Lista de notas retornada com sucesso
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   chave:
 *                     type: string
 *                     example: "35260712345678000123550010000012341000012345"
 *                   numero:
 *                     type: string
 *                     example: "1234"
 *                   serie:
 *                     type: string
 *                     example: "1"
 *                   emitente:
 *                     type: string
 *                     example: "Empresa Exemplo LTDA"
 *                   cnpj:
 *                     type: string
 *                     example: "12345678000199"
 *                   valorTotal:
 *                     type: number
 *                     example: 1500.75
 *                   status:
 *                     type: string
 *                     example: "PROCESSADA"
 *       500:
 *         description: Erro interno do servidor
 */
router.get("/notas", xmlController.listarNotas);


/**
 * @swagger
 * /api/nao-identificados:
 *   get:
 *     summary: Lista notas fiscais não identificadas
 *     description: Retorna notas cujo cliente ou vínculo não foi identificado no processamento.
 *     tags:
 *       - Notas Fiscais
 *     responses:
 *       200:
 *         description: Lista de notas não identificadas retornada com sucesso
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   chave:
 *                     type: string
 *                     example: "35260712345678000123550010000012341000012345"
 *                   numero:
 *                     type: string
 *                     example: "1234"
 *                   emitente:
 *                     type: string
 *                     example: "Fornecedor XYZ"
 *                   motivo:
 *                     type: string
 *                     example: "Cliente não encontrado na base"
 *                   status:
 *                     type: string
 *                     example: "NÃO IDENTIFICADA"
 *       500:
 *         description: Erro interno do servidor
 */
router.get(
    "/nao-identificados",
    xmlController.listarNaoIdentificados
);

export default router;