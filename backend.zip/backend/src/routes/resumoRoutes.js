import express from "express";
import * as resumoController from "../controllers/resumoController.js";

const router = express.Router();

/**
 * @swagger
 * /api/resumo:
 *   get:
 *     summary: Retorna o resumo das notas fiscais processadas
 *     description: Lista informações consolidadas das notas fiscais armazenadas no sistema.
 *     tags:
 *       - Resumo
 *     responses:
 *       200:
 *         description: Resumo retornado com sucesso
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   totalNotas:
 *                     type: integer
 *                     example: 150
 *                   valorTotal:
 *                     type: number
 *                     example: 45890.75
 *                   notasProcessadas:
 *                     type: integer
 *                     example: 120
 *                   notasPendentes:
 *                     type: integer
 *                     example: 30
 *       500:
 *         description: Erro interno do servidor
 */
router.get("/resumo", resumoController.listarResumo);

export default router;