import NotaFiscal from "../models/Nota.js";

export async function salvar(nota) {
    return await NotaFiscal.create(nota);
}

export async function listarNotas() {
    return await NotaFiscal.find();
}

export async function buscarPorChave(chave) {
    return await NotaFiscal.findOne({ chave });
}

export async function listarNaoIdentificados() {
    return await NotaFiscal.find({
        tipoOperacao: "Não identificado"
    });
}

export async function buscarResumo() {
    return await NotaFiscal.aggregate([
        {
            $match: { tipoOperacao: { $ne: "Não identificado" }, cliente: { $ne: null} }
        },
        {
            $group: {
                _id: "$cliente",
                compra: {
                    $sum: {
                        $cond: [{ $eq: ["$tipoOperacao", "Compra"] }, "$valorTotal", 0]
                    }
                },
                venda: {
                    $sum: {
                        $cond: [{ $eq: ["$tipoOperacao", "Venda"] }, "$valorTotal", 0]
                    }
                }
            }
        },
        {
            $project: {
                _id: 0,
                cliente: "$_id",
                compra: 1,
                venda: 1
            }
        }
    ]);
}