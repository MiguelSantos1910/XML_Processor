import mongoose from "mongoose";

const NotaSchema = new mongoose.Schema({
    emitente: {
        type: String,
        required: true
    },
    chaveNota: {
        type: String,
        required: true,
        unique: true
    },
    destinatario: {
        type: String,
        required: true
    },
    cnpjEmitente: {
        type: String,
        required: true
    },
    cnpjDestinatario: {
        type: String,
        required: true
    },
    valorTotal: {
        type: Number,
        required: true
    },
    dataEmissao: {
        type: Date,
        required: true
    },
    tipoOperacao: {
        type: String,
        enum: ["Compra", "Venda", "Não identificado"],
        required: true
    },
    cliente: {type: String},
    motivo: {type: String}
}, {
    timestamps: true
});

export default mongoose.model("Nota", NotaSchema);