import { lerXML } from "../services/xmlParserService.js";
import { buscarClientes } from "../services/clienteService.js";
import { processarNota } from "../services/notaFiscalService.js";

export async function processarXML(caminhoArquivo){
    const nota = await lerXML(caminhoArquivo);
    const clientes = await buscarClientes();
    await processarNota(nota, clientes);
}