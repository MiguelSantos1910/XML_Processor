import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import uploadRoutes from "../src/routes/uploadRoutes.js";
import xmlRoutes from "../src/routes/xmlRoutes.js";
import resumoRoutes from "../src/routes/resumoRoutes.js";
import swaggerUi from "swagger-ui-express";
import swaggerSpec from "./config/swagger.js";
import pinoHttp from "pino-http";
import logger from "./config/logger.js";
import { tratamentoErros } from './middlewares/erros.js';

dotenv.config();
const app = express();

//middlewares
app.use(express.json());
app.use(cors());
app.use(pinoHttp({ logger }));
app.use(express.urlencoded({extended: true}));

//pasta uploads
app.use("/uploads", express.static("uploads"));

//rotas
app.use("/api/xml", xmlRoutes);
app.use("/api/xml", uploadRoutes);
app.use("/api/dashboard", resumoRoutes);

//Swagger
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));

//API ok
app.get("/", async(req, res) =>{
    res.status(200).json({mensagem: "API em funcionamento!"});
});

//Tratamento de erros
app.use(tratamentoErros);

export default app;