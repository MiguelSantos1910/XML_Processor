import dotenv from "dotenv";
import app from "../backend/src/app.js";
import { conectarBanco } from "../backend/src/config/database.js";
import logger from "../backend/src/config/logger.js";

dotenv.config();
const PORT = process.env.PORT || 3001;

async function iniciarServidor() {
    await conectarBanco();
    app.listen(PORT, () => {
        logger.info(`Servidor rodando na porta ${PORT}`);
    });
}

iniciarServidor();